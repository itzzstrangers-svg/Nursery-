const plants = [
  {
    id:1,name:"Tulsi",scientific:"Ocimum tenuiflorum",category:"Medicinal Plant",icon:"🌿",
    sunlight:"Medium to High",water:"Medium",soil:"Well-drained soil",season:"Warm season",
    benefits:"Aromatic plant commonly grown in homes and gardens. Traditionally valued in many households.",
    care:"Provide good light, moderate watering and avoid waterlogging."
  },
  {
    id:2,name:"Aloe Vera",scientific:"Aloe barbadensis miller",category:"Medicinal Plant",icon:"🌵",
    sunlight:"High",water:"Low",soil:"Sandy, well-drained soil",season:"Warm season",
    benefits:"A hardy succulent and popular container plant.",
    care:"Allow soil to dry between watering and provide good drainage."
  },
  {
    id:3,name:"Rose",scientific:"Rosa",category:"Flowering Plant",icon:"🌹",
    sunlight:"High",water:"Medium",soil:"Rich, well-drained soil",season:"Cool to moderate season",
    benefits:"Popular ornamental plant with attractive flowers.",
    care:"Provide sunlight, moderate water and remove dead flowers when needed."
  },
  {
    id:4,name:"Snake Plant",scientific:"Dracaena trifasciata",category:"Indoor Plant",icon:"🪴",
    sunlight:"Low to Medium",water:"Low",soil:"Well-drained potting mix",season:"Year-round indoors",
    benefits:"Hardy and popular low-maintenance indoor ornamental plant.",
    care:"Avoid overwatering and provide indirect light where possible."
  },
  {
    id:5,name:"Marigold",scientific:"Tagetes",category:"Flowering Plant",icon:"🌼",
    sunlight:"High",water:"Medium",soil:"Well-drained fertile soil",season:"Cool season",
    benefits:"Colorful flowering plant commonly grown in gardens.",
    care:"Provide sunlight and avoid excessive moisture around roots."
  },
  {
    id:6,name:"Cactus",scientific:"Cactaceae",category:"Indoor Plant",icon:"🌵",
    sunlight:"High",water:"Low",soil:"Very well-drained sandy soil",season:"Warm season",
    benefits:"Low-water ornamental option for bright locations.",
    care:"Use a draining pot and water only when the soil is dry."
  },
  {
    id:7,name:"Hibiscus",scientific:"Hibiscus rosa-sinensis",category:"Flowering Plant",icon:"🌺",
    sunlight:"High",water:"Medium",soil:"Rich, well-drained soil",season:"Warm season",
    benefits:"Popular flowering garden plant.",
    care:"Provide good sunlight, regular but controlled watering and suitable soil."
  },
  {
    id:8,name:"Mint",scientific:"Mentha",category:"Medicinal Plant",icon:"🌱",
    sunlight:"Medium",water:"High",soil:"Moist, well-drained soil",season:"Cool to moderate season",
    benefits:"Aromatic herb commonly grown in home gardens and containers.",
    care:"Keep soil moderately moist and provide light without excessive heat."
  },
  {
    id:9,name:"Tomato",scientific:"Solanum lycopersicum",category:"Vegetable Plant",icon:"🍅",
    sunlight:"High",water:"Medium",soil:"Fertile, well-drained soil",season:"Suitable growing season",
    benefits:"Common home-garden vegetable.",
    care:"Provide sunlight, support the plant and maintain consistent soil moisture."
  },
  {
    id:10,name:"Mango",scientific:"Mangifera indica",category:"Fruit Plant",icon:"🥭",
    sunlight:"High",water:"Medium",soil:"Deep, well-drained soil",season:"Warm climate",
    benefits:"Important fruit tree with edible fruit and long-term garden value.",
    care:"Needs adequate space, sunlight and appropriate watering while establishing."
  }
];

const nurseries = [
  {
    name:"Demo Green Nursery",location:"Replace with your local nursery",
    phone:"0000000000",hours:"08:00 AM - 07:00 PM",
    services:"Plants, pots and basic gardening guidance",icon:"🏪"
  },
  {
    name:"Community Plant Nursery",location:"Add your community address",
    phone:"0000000000",hours:"09:00 AM - 06:00 PM",
    services:"Flowering, medicinal and ornamental plants",icon:"🌳"
  },
  {
    name:"Local Garden Center",location:"Add local location",
    phone:"0000000000",hours:"08:30 AM - 06:30 PM",
    services:"Plants, seeds and gardening materials",icon:"🌿"
  }
];

const plantGrid=document.getElementById("plantGrid");
const noPlants=document.getElementById("noPlants");
const searchInput=document.getElementById("searchInput");
const categoryFilter=document.getElementById("categoryFilter");

function renderPlants(){
  const q=(searchInput.value||"").toLowerCase().trim();
  const cat=categoryFilter.value;
  const filtered=plants.filter(p=>{
    const matchesText=[p.name,p.scientific,p.category,p.benefits].join(" ").toLowerCase().includes(q);
    const matchesCat=cat==="all" || p.category===cat;
    return matchesText && matchesCat;
  });
  plantGrid.innerHTML=filtered.map(p=>`
    <article class="plant-card">
      <div class="plant-image">${p.icon}</div>
      <div class="plant-body">
        <span class="tag">${p.category}</span>
        <h3>${p.name}</h3>
        <p><i>${p.scientific}</i></p>
        <p>${p.benefits}</p>
        <button class="btn small" onclick="openPlant(${p.id})">View Details</button>
      </div>
    </article>
  `).join("");
  noPlants.classList.toggle("hidden",filtered.length!==0);
}
searchInput.addEventListener("input",renderPlants);
categoryFilter.addEventListener("change",renderPlants);

const nurseryGrid=document.getElementById("nurseryGrid");
nurseryGrid.innerHTML=nurseries.map(n=>`
  <article class="nursery-card">
    <div class="nursery-icon">${n.icon}</div>
    <h3>${n.name}</h3>
    <p>📍 ${n.location}</p>
    <p>📞 ${n.phone}</p>
    <p>🕒 ${n.hours}</p>
    <p><b>Services:</b> ${n.services}</p>
  </article>
`).join("");

const modal=document.getElementById("plantModal");
const modalBody=document.getElementById("modalBody");
function openPlant(id){
  const p=plants.find(x=>x.id===id);
  if(!p)return;
  modalBody.innerHTML=`
    <div class="detail-icon">${p.icon}</div>
    <span class="tag">${p.category}</span>
    <h2>${p.name}</h2>
    <p><i>${p.scientific}</i></p>
    <p>${p.benefits}</p>
    <div class="detail-grid">
      <div><b>☀️ Sunlight</b><br>${p.sunlight}</div>
      <div><b>💧 Water</b><br>${p.water}</div>
      <div><b>🌱 Soil</b><br>${p.soil}</div>
      <div><b>📅 Season</b><br>${p.season}</div>
    </div>
    <h3>Care Instructions</h3>
    <p>${p.care}</p>
  `;
  modal.classList.add("show");
  document.body.style.overflow="hidden";
}
document.getElementById("closeModal").onclick=closeModal;
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
function closeModal(){modal.classList.remove("show");document.body.style.overflow="";}

const choices={space:null,sun:null,water:null};
document.querySelectorAll(".options").forEach(group=>{
  const name=group.dataset.group;
  group.querySelectorAll("button").forEach(btn=>{
    btn.addEventListener("click",()=>{
      group.querySelectorAll("button").forEach(b=>b.classList.remove("selected"));
      btn.classList.add("selected");
      choices[name]=btn.dataset.value;
    });
  });
});

document.getElementById("recommendBtn").addEventListener("click",()=>{
  const result=document.getElementById("recommendResult");
  if(!choices.space||!choices.sun||!choices.water){
    result.innerHTML="<p class='form-message'>Please select one option in all three questions.</p>";
    return;
  }

  let scored=plants.map(p=>{
    let score=0;
    if(p.sunlight.toLowerCase().includes(choices.sun.toLowerCase())) score+=3;
    if(p.water.toLowerCase().includes(choices.water.toLowerCase())) score+=3;
    if(choices.space==="Indoor" && p.category==="Indoor Plant") score+=3;
    if(choices.space==="Balcony" && ["Indoor Plant","Flowering Plant","Medicinal Plant"].includes(p.category)) score+=2;
    if(choices.space==="Garden" && p.category!=="Indoor Plant") score+=2;
    if(choices.space==="Farm" && ["Fruit Plant","Vegetable Plant"].includes(p.category)) score+=3;
    return {...p,score};
  }).sort((a,b)=>b.score-a.score).slice(0,3);

  result.innerHTML=`
    <div class="result-title">🌱 Recommended for your conditions</div>
    <p>Space: <b>${choices.space}</b> · Sunlight: <b>${choices.sun}</b> · Water: <b>${choices.water}</b></p>
    <div class="result-list">
      ${scored.map(p=>`<div class="result-item"><div style="font-size:2rem">${p.icon}</div><b>${p.name}</b><br><small>${p.category}</small></div>`).join("")}
    </div>
  `;
});

document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.getElementById("contactName").value.trim();
  document.getElementById("formMessage").textContent=
    `Thank you, ${name}! Your inquiry has been recorded on this demo website.`;
  e.target.reset();
});

document.getElementById("year").textContent=new Date().getFullYear();

const menuBtn=document.getElementById("menuBtn");
const navMenu=document.getElementById("navMenu");
menuBtn.addEventListener("click",()=>navMenu.classList.toggle("show"));
navMenu.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>navMenu.classList.remove("show")));

renderPlants();
